/* eslint-disable no-inner-declarations */
(function () {
    function domainCheck() {
        var currentHost = window.location.host
        var hostCheck = false
        if (currentHost === "qa2-ui.i.balsamhill.com" || currentHost === "qa2-ui.i.balsamhill.co.uk" || currentHost === "qa2-ui.i.balsamhill.com.au") {
            hostCheck = true
        }
        if (currentHost === "prod-ui.i.balsamhill.com" || currentHost === "prod-ui.i.balsamhill.co.uk" || currentHost === "prod-ui.i.balsamhill.com.au") {
            if (getVisitorId() === "aee9ce1aaeeb8e13719b8e130e0b96170e0f0d74fb") {
                hostCheck = true
            }
        }
        
        if (currentHost === "www.balsamhill.com" || currentHost === "www.balsamhill.co.uk" || currentHost === "www.balsamhill.com.au" || window.location.host === 'uat-ui.i.balsamhill.com') {
            hostCheck = true
        }
        return hostCheck
    }




    function generateRandomString(bits1) {
        return (crypto.getRandomValues(new Uint32Array(1))[0] / 4294967295).toString(bits1).substring(2, 15) + (crypto.getRandomValues(new Uint32Array(1))[0] / 4294967295).toString(bits1).substring(2, 15);
    }

    function getVisitorId() {
        function generateUniqueINCVisitorId(len, bits) {
            var bits1 = bits || 36;
            var outStr = "";
            var newStr;
            while (outStr.length < len) {
                newStr = generateRandomString(bits1).toString().slice(2);
                outStr += newStr.slice(0, Math.min(newStr.length, (len - outStr.length)));
            }
            return outStr;
        }
        var clientdomain = window.location.host
        var arr = clientdomain.split(".");
        var d = new Date();
        var expires = "expires=" + d.toUTCString();
        var ivid = "";
        if (readCookie('ivid') != undefined) {
            ivid = readCookie('ivid')
        }
        if (ivid.length == 0) {
            ivid = generateUniqueINCVisitorId(42, 16);
            arr.shift();
            clientdomain = arr.join(".");
            if (arr == 'com' || window.location.host.indexOf('www') == -1) {
                clientdomain = window.location.host;
            }
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            expires = "expires=" + d.toUTCString();
            document.cookie = 'ivid=' + ivid + '; expires=' + expires + '; domain=' + clientdomain + '; path=/' + '; secure;'
        } else {
            arr.shift();
            clientdomain = arr.join(".");
            if (arr == 'com' || window.location.host.indexOf('www') == -1) {
                clientdomain = window.location.host;
            }
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            expires = "expires=" + d.toUTCString();
            document.cookie = 'ivid=' + ivid + '; expires=' + expires + '; domain=' + clientdomain + '; path=/' + '; secure;'
        }
        return ivid;
    }
    getVisitorId()

    fetch('/api/auth/session')
        .then((response) => response.json())
        .then((data) => {
            if (Object.keys(data).length !== 0) {
                if (data.isUserLoggedIn) {
                    localStorage.setItem('inc_isln', true)
                } else {
                    localStorage.setItem('inc_isln', false)
                }
            } else {
                localStorage.setItem('inc_isln', false)
            }
        })
        .catch(function () {
            localStorage.setItem('inc_isln', false)
        });

    function readCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var s of ca) {
            var c = s;
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }
    // Crawl Script

    let getCurrentFormattedTime = () => {
        let d = new Date();
        return (`${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()} ${d.getHours()}:${d.getMinutes()}:${d.getSeconds()}.${d.getMilliseconds()}`);
    };
    let getURLBasedCountryCode = () => {
        function readIVID(name) {
            let nameEQ = `${name}=`;
            let ca = document.cookie.split(';');
            for (let s in ca) {
                if (Object.prototype.hasOwnProperty.call(ca, s)) {
                    let c = ca[s];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1, c.length);
                    }
                    if (c.indexOf(nameEQ) == 0) {
                        return c.substring(nameEQ.length, c.length);
                    }
                }
            }
            return null;
        }

        if (window.location.host === 'prod-ui.i.balsamhill.co.uk' && readIVID('ivid') === 'aee9ce1aaeeb8e13719b8e130e0b96170e0f0d74fb') {
            let value = 'b1Al5UmUK';
            if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]')) {
                if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]').value === '€') {
                    value = 'bALwe2Re';
                }
            }
            return value;
        }
        if (window.location.host === 'prod-ui.i.balsamhill.com' && readIVID('ivid') === 'aee9ce1aaeeb8e13719b8e130e0b96170e0f0d74fb') {
            return 'b1Al5UmUS';
        }
        if (window.location.host === 'prod-ui.i.balsamhill.com.au' && readIVID('ivid') === 'aee9ce1aaeeb8e13719b8e130e0b96170e0f0d74fb') {
            return 'b1Al5UmAU';
        }

        if (window.location.host === 'www.balsamhill.co.uk') {
            let value = 'b58luk';
            if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]')) {
                if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]').value === '€') {
                    value = 'b58leuro';
                }
            }
            return value;
        }
        if (window.location.host === 'www.balsamhill.com') {
            return 'b58lus';
        }
        if (window.location.host === 'www.balsamhill.com.au') {
            return 'b58lau';
        }

        if (window.location.host === 'qa2-ui.i.balsamhill.co.uk') {
            let value = 'b17s0mReQ6UK';
            if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]')) {
                if (document.querySelector('.currency-dropdown-radio-desktop.form-check-input[checked]').value === '€') {
                    value = 'b15eUroUK';
                }
            }
            return value;
        }
        if (window.location.host === 'qa2-ui.i.balsamhill.com') {
            return 'b17s0mReQ6';
        }
        if (window.location.host === 'qa2-ui.i.balsamhill.com.au') {
            return 'b17s0mReQ6AU';
        }

        if (window.location.host === 'uat-ui.i.balsamhill.co.uk') {
            return 'b17s0mReQ6UK';
        }
        if (window.location.host === 'uat-ui.i.balsamhill.com.au') {
            return 'b17s0mReQ6AU';
        }
        if (window.location.host === 'uat-ui.i.balsamhill.com') {
            return 'b17s0mReQ6';
        }

        return 'b17s0mReQ6';
    };
    let countryByName = () => {
        if (getURLBasedCountryCode() === 'b17s0mReQ6AU') {
            return 'Australia';
        } if (getURLBasedCountryCode() === 'b15eUroUK') {
            return 'United Kingdom';
        } if (getURLBasedCountryCode() === 'b17s0mReQ6UK') {
            return 'United Kingdom';
        } if (getURLBasedCountryCode() === 'b17s0mReQ6') {
            return 'United States';
        }
        if (getURLBasedCountryCode() === 'bALwe2Re') {
            return 'United Kingdom';
        }

        if (getURLBasedCountryCode() === 'b1Al5UmUK') {
            return 'United Kingdom';
        }
        if (getURLBasedCountryCode() === 'b1Al5UmUS') {
            return 'United States';
        }
        if (getURLBasedCountryCode() === 'b1Al5UmAU') {
            return 'Australia';
        }
        // LIVE FEED
        if (getURLBasedCountryCode() === 'b58luk') {
            return 'United Kingdom';
        }
        if (getURLBasedCountryCode() === 'b58leuro') {
            return 'United Kingdom';
        }
        if (getURLBasedCountryCode() === 'b58lus') {
            return 'United States';
        }
        if (getURLBasedCountryCode() === 'b58lau') {
            return 'Australia';
        }
    };

    /**
    *
    *  Base64 encode / decode
    *  http://www.webtoolkit.info/
    *
    **/
    var Base64 = {

        // private property
        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

        // public method for encoding
        encode: function (input) {
            var output = "";
            var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
            var i = 0;

            input = Base64._utf8_encode(input);

            while (i < input.length) {

                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);

                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;

                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }

                output = output +
                    this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
                    this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
            }
            return output;
        },

        // public method for decoding
        decode: function (input) {
            var output = "";
            var chr1, chr2, chr3;
            var enc1, enc2, enc3, enc4;
            var i = 0;

            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

            while (i < input.length) {

                enc1 = this._keyStr.indexOf(input.charAt(i++));
                enc2 = this._keyStr.indexOf(input.charAt(i++));
                enc3 = this._keyStr.indexOf(input.charAt(i++));
                enc4 = this._keyStr.indexOf(input.charAt(i++));

                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;

                output = output + String.fromCharCode(chr1);

                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }
            }

            output = Base64._utf8_decode(output);

            return output;
        },

        // private method for UTF-8 encoding
        _utf8_encode: function (string) {
            string = string.replace(/\r\n/g, "\n");
            var utftext = "";

            for (var n = 0; n < string.length; n++) {

                var c = string.charCodeAt(n);

                if (c < 128) {
                    utftext += String.fromCharCode(c);
                }
                else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
                else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }
            return utftext;
        },

        // private method for UTF-8 decoding
        _utf8_decode: function (utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;

            while (i < utftext.length) {

                c = utftext.charCodeAt(i);

                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                }
                else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                }
                else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }
            }
            return string;
        }
    }

    let final_category;
    let final_product_ids;

    function categoryCrawl() {
        return
        let productLayerprod = [];

        var catergory_id; var
            product_ids;
        var empty_obj = {};
        if (document.querySelector('#productschema') != null) {
            let prdcategory = '';
            let catcount = 0;
            if (document.querySelectorAll('.breadcrumb .breadcrumb-item') != null) {
                let catlist = document.querySelectorAll('.breadcrumb .breadcrumb-item');
                for (let c = 0; c < catlist.length; c++) {
                    if (catlist[c].innerText != 'Home') {
                        if (catcount == 0) {
                            prdcategory = catlist[c].innerText;
                        } else {
                            prdcategory = `${prdcategory}|${catlist[c].innerText}`;
                        }
                        catcount++;
                    }
                }
            }
            if (prdcategory != "" && prdcategory != undefined) {
                prdcategory = prdcategory.split('|')[prdcategory.split('|').length - 1]
            }
            if (prdcategory == 'Decorative Accents' && window.location.pathname == '/c/fall-decorative-accents') {
                prdcategory = 'Fall Decorative Accents'
            } else if (prdcategory == 'Catalog Picks' && window.location.pathname == '/c/featured-spring-decor') {
                prdcategory = 'Spring Catalog Picks'
            } else if (prdcategory == 'Christmas Decorations' && window.location.pathname == '/c/christmas-ornaments-storage-and-bags') {
                prdcategory = 'Christmas ornaments storage and bags'
            }
            if (window.location.pathname == "/c/new-artificial-christmas-trees" && countryByName() == "United States") {
                prdcategory = "New Artificial Christmas Trees"
             }
            let arrayOfIdsFromPage = []
            document
            .querySelectorAll(
                ".listingContainer_product-listing-item-wrapper__QtCb_"
            )
            .forEach((item) => {
                if (item.getAttribute("data-cnstrc-item-id")) {
                    let split = item.getAttribute("data-cnstrc-item-id");
                    if (split) {
                        arrayOfIdsFromPage.push(split);
                    }
                }
            });
            // let allIDS = document.querySelectorAll('.productCard_title__60NqS')[0].getAttribute('data-testid').split('productListing_')[1]
            let dataList = arrayOfIdsFromPage
            for (l = 0; l < dataList.length; l++) {
                productLayerprod.push({
                    category: prdcategory,
                    productList: dataList[l],
                });
            }

            productLayerprod.forEach((ele) => {
                if (empty_obj[ele.category]) {
                    empty_obj[ele.category] += `,${ele.productList}`;
                } else {
                    empty_obj[ele.category] = ele.productList;
                }
            });

            var product_arr = [];
            for (let property in empty_obj) {
                catergory_id = property;
                product_arr.push(empty_obj[property]);
            }

            if (product_arr.length > 1) {
                let pids = '';
                product_arr.forEach((ele) => {
                    pids += `,${ele}`;
                });
                product_ids = pids.replace(',', '');
            } else {
                product_ids = product_arr[0];
            }

            final_category = catergory_id;
            final_product_ids = product_ids;

            if (productLayerprod.length == 0 || productLayerprod == undefined) {
                let plpproductlist = [];
                let productidscategory = [];
                let productselm = document.querySelectorAll('.layout-product-tile-holder .product-tile .product-tile-basket__btn');
                var empty_obj = {};
                var catergory_id; var
                    product_ids;
                for (p = 0; p < productselm.length; p++) {
                    let id = productselm[p].id.replace('pListBtn', '');
                    plpproductlist.push(id);
                }
                let product_category = [];
                let pr_cat = document.querySelectorAll('.breadcrumb__item.breadcrumb__item--show');
                for (let j = 0; j < pr_cat.length; j++) {
                    if (j != 0) {
                        let category_data = pr_cat[j].innerText.trim();
                        product_category.push(category_data);
                    }
                }
                productidscategory.push({
                    category: product_category[product_category.length - 1],
                    productList: plpproductlist,
                });

                productidscategory.forEach((ele) => {
                    if (empty_obj[ele.category]) {
                        empty_obj[ele.category] += `,${ele.productList}`;
                    } else {
                        empty_obj[ele.category] = ele.productList;
                    }
                });

                var product_arr = [];

                for (let property in empty_obj) {
                    catergory_id = property;
                    product_ids = empty_obj[property];
                }

                product_ids = product_ids.filter((ele) => {
                    if (ele == '') {

                    } else {
                        return ele;
                    }
                }).join();

                final_category = catergory_id;
                final_product_ids = product_ids;

                // console.log("Second_Method---->", catergory_id,product_ids)
            }
            setTimeout(() => {
                if (window.location.pathname === "/c/best-selling-artificial-christmas-trees") {
                    final_category = final_category.replace('Best Sellers', 'Best Selling Artificial Christmas Trees')
                }
                // console.log('Category--->', final_category, 'Products--->', final_product_ids);
                let tricrawl = false;
                if (document.querySelector('.produt-listing-content') != null || document.querySelector('.produt-listing-container') != null) {
                    tricrawl = true;
                } else if (typeof (br_data) !== 'undefined') {
                    if (br_data != undefined) {
                        if (br_data.ptype == 'category') {
                            tricrawl = true;
                        }
                    }
                }

                if (tricrawl == true && (final_category != undefined && final_product_ids != undefined)) {
                    let format_json_data;

                    let product_id = final_product_ids.split(',')[0];

                    format_json_data = JSON.stringify({
                        event_data: {
                            product_id,
                            field1: final_category,
                            description: final_product_ids,
                        },
                        event_type: 'product_page_visit',
                        method: 'track',
                        token: getURLBasedCountryCode(),
                    });
                    if (!product_id) return

                    let data = {
                        eventData: Base64.encode(format_json_data),
                        vid: readCookie('ivid'),
                        time: getCurrentFormattedTime(),
                        uri: document.location.href,
                    };
                    let p_url = 'https://gather.increasingly.com/ImportCrawledData';
                    if (countryByName() === 'United States') {
                        p_url = 'https://usagather.increasingly.com/ImportCrawledData';
                    }
                    if (countryByName() === 'Australia') {
                        p_url = 'https://jpgather.increasingly.com/ImportCrawledData';
                    }
                    let xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == XMLHttpRequest.DONE) {
                            if (xhr.status == 200) {
                                if (xhr.responseText != '' && xhr.responseText != null) { } else { }
                            }
                        }
                    };
                    xhr.open('POST', p_url, true);
                    xhr.setRequestHeader('Content-Type', 'application/json');
                    xhr.send(JSON.stringify(data));
                }
            }, 200);
        }
    }


    // End Crawl

    if (domainCheck() === false) return



    function pageTypeCheck() {
        if (window.location.pathname === '/') {
            return 'HomePage';
        } if (window.location.pathname === '/cart') {
            return 'CartPage';
        } if (window.location.pathname.includes('/p/')) {
            return 'ProductPage';
        } if (window.location.pathname.includes('/c/')) {
            return 'ProductList';
        } if (window.location.pathname.includes('/search')) {
            return 'SearchPage';
        } if (window.location.pathname.includes('/inspiration')) {
            return 'ContentPage';
        }
        if (window.location.pathname.includes('/f/')) {
            return 'ProductPage';
        }
        return null;
    }
    var versionUpdate = (new Date()).getTime();

    if (pageTypeCheck() !== null) {
        function addCSSFile() {
            var cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.css?v=" + versionUpdate;
            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.css?v=" + versionUpdate;
            }
            var linkTag = document.createElement('link');
            linkTag.rel = "stylesheet";
            linkTag.href = cssFilePath;
            document.querySelector('head').appendChild(linkTag);
        }
        addCSSFile()
        var fpdpid = "";
        setTimeout(function () {
            for (let p = 0; p <= window.dataLayer.length; p++){
                if(window.dataLayer[p]){
                    if (window.dataLayer[p].event == 'product_view'){
                        if (window.dataLayer[p].sku){
                        let isNumericId = /^-?\d+(\.\d+)?$/.test(window.dataLayer[p].sku);
                            if(!isNumericId && window.location.href.includes(window.dataLayer[p].product_id[0]) == true){
                                fpdpid = window.dataLayer[p].sku
                            }
                        }
                    }
                }
            }
            if(document.querySelector('#product-variant-selector') != null) {
                fpdpid = document.querySelector('#product-variant-selector').dataset["cnstrcItemParentId"]
            }
            if (!window.location.pathname.includes('/p/') && !window.location.pathname.includes('/f/')) {
                fpdpid = "enable"
            }
            if(fpdpid != "") {
                loadScriptWithVersion();
                console.log("initial page check" , fpdpid)
            } else {
                setTimeout(function(){
                    if(document.querySelector('#product-variant-selector') != null) {
                        fpdpid = document.querySelector('#product-variant-selector').dataset["cnstrcItemParentId"]
                    }
                    if(fpdpid != "") {
                        loadScriptWithVersion();
                        console.log("initial page check" , fpdpid)
                    } else {
                        setTimeout(function(){
                            loadScriptWithVersion();
                            console.log("initial page check-" , fpdpid)
                        },1000)
                    }
                },1000)
            }
        },2000)

        function loadScriptWithVersion() {
            var jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.js?v=" + versionUpdate
            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.js?v=" + versionUpdate
            }
            var scriptTag = document.createElement('script');
            scriptTag.setAttribute('async', '');
            scriptTag.setAttribute('class', 'inc_js_files_' + versionUpdate);
            scriptTag.type = 'text/javascript';
            scriptTag.src = jsFilePath;
            document.body.appendChild(scriptTag);

            setTimeout(function () {
                var addedScript = document.querySelector('.inc_js_files_' + versionUpdate);
                if (addedScript) {
                    addedScript.className = "c";
                } else {
                    console.error('Failed to load the script.');
                }
            }, 2000);
        }
    }
    var previousUrl = location.pathname;
    let lastProductCount = ""
    if (document.querySelectorAll('.productCard_title__60NqS')) {
        lastProductCount = document.querySelectorAll('.productCard_title__60NqS').length
    }

    let onload = true
    let lastPageType = ""
    let presentCart = ""


    function inc_delete_old() {
        if (document.querySelector('#inc_pdp_1')) document.querySelector('#inc_pdp_1').innerHTML = ""
        if (document.querySelector('#inc_pdp_2')) document.querySelector('#inc_pdp_2').innerHTML = ""
        if (document.querySelector('#inc_pdp_3')) document.querySelector('#inc_pdp_3').innerHTML = ""
        if (document.querySelector('#inc_plp_1')) document.querySelector('#inc_plp_1').innerHTML = ""
        if (document.querySelector('#inc_plp_2')) document.querySelector('#inc_plp_2').innerHTML = ""
        if (document.querySelector('#inc_home_page_1')) document.querySelector('#inc_home_page_1').innerHTML = ""
        if (document.querySelector('#inc_home_page_2')) document.querySelector('#inc_home_page_2').innerHTML = ""
        if (document.querySelector('#inc_home_page_3')) document.querySelector('#inc_home_page_3').innerHTML = ""
        if (document.querySelector('#inc_cart_1')) document.querySelector('#inc_cart_1').innerHTML = ""
        if (document.querySelector('#inc_cart_2')) document.querySelector('#inc_cart_2').innerHTML = ""
        if (document.querySelector('#inc_empty_cart_1')) document.querySelector('#inc_empty_cart_1').innerHTML = ""
        if (document.querySelector('#inc_empty_cart_2')) document.querySelector('#inc_empty_cart_2').innerHTML = ""
        if (document.querySelector('#inc_content_page_1')) document.querySelector('#inc_content_page_1').innerHTML = ""
        if (document.querySelector('#inc_content_page_2')) document.querySelector('#inc_content_page_2').innerHTML = ""
        if (document.querySelector('#inc_content_page_3')) document.querySelector('#inc_content_page_3').innerHTML = ""


    }

    function hide_plp() {
        if (window.location.pathname.includes('/c/')) {
            if (document.querySelector('#inc_plp_1')) {
                if (document.querySelector('#inc_plp_1').parentElement) {
                    if (document.querySelector('#inc_plp_1').parentElement.parentElement) {
                        document.querySelector('#inc_plp_1').parentElement.parentElement.style.setProperty('display', 'none', 'important')
                    }
                }
            }
        }
    }
    // observer.observe(document, config);
    let oldPath = window.location.pathname;
    let oldSearch = window.location.search;
    const observer = new MutationObserver((mutationsList, observer) => {
        const currentPath = window.location.pathname;
        const currentSearch = window.location.search;

        // Detect URL path change
        if (oldPath !== currentPath) {
            console.log('Pathname changed:', oldPath, '→', currentPath);
            oldPath = currentPath;
            handlePageChange();
        }

        // Detect search param change (e.g., filters/search in PLP)
        if (oldSearch !== currentSearch) {
            console.log('Search changed:', oldSearch, '→', currentSearch);
            oldSearch = currentSearch;
            handleSearchChange();
        }

        // Optional: Detect child mutations
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
            // Handle added/removed nodes
            // console.log('DOM change detected');
            }
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    function handlePageChange() {
        onload = true
        previousUrl = location.pathname;
        // console.log("Detected SPA Change")
        fetch('/api/auth/session')
            .then((response) => response.json())
            .then((data) => {
                if (Object.keys(data).length !== 0) {
                    if (data.isUserLoggedIn) {
                        localStorage.setItem('inc_isln', true)
                    } else {
                        localStorage.setItem('inc_isln', false)
                    }
                } else {
                    localStorage.setItem('inc_isln', false)
                }
            })
            .catch(function () {
                localStorage.setItem('inc_isln', false)
            });
        inc_delete_old()
        hide_plp()
        lastPageType = pageTypeCheck()

        setTimeout(() => {
            if (document.querySelector('#inc_cart_1') || document.querySelector('#inc_cart_2')) {
                presentCart = "product_cart"
            } else if (document.querySelector('#inc_empty_cart_1') || document.querySelector('#inc_empty_cart_2')) {
                presentCart = "empty_cart"
            }
            if (pageTypeCheck() !== null) {
                if (document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/bA15huS/js/increasingly_bA15huS.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/b58lus/js/increasingly_b58lus.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://jp.increasingly.co/Implementation/bA15haU/js/increasingly_bA15haU.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://www.increasingly.co/Implementation/bA15huK/js/increasingly_bA15huK.js?v=1.0"]').length >= 1) {
                    if (document.querySelector('.inc_js_files_' + versionUpdate + '') == null && window.location.href.indexOf('checkout') == -1) {
                        function addCSSFile() {
                            var cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.css?v=" + versionUpdate;
                            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.css?v=" + versionUpdate;
                            }
                            var linkTag = document.createElement('link');
                            linkTag.rel = "stylesheet";
                            linkTag.href = cssFilePath;
                            document.querySelector('head').appendChild(linkTag);
                        }
                        addCSSFile()
                        setTimeout(() => {
                            var jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.js?v=" + versionUpdate
                            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.js?v=" + versionUpdate
                            }
                            var scriptTag = document.createElement('script');
                            scriptTag.setAttribute('class', 'inc_js_files_' + versionUpdate + '')
                            scriptTag.type = 'text/javascript';
                            scriptTag.src = jsFilePath;
                            document.querySelector('body').appendChild(scriptTag);
                            setTimeout(function () {
                                if (document.querySelector('.inc_js_files_' + versionUpdate + '') != null) {
                                    document.querySelector('.inc_js_files_' + versionUpdate + '').className = "c"
                                }
                            }, 2000)
                        }, 500);
                    }
                }
                // Crawling
                if (window.location.pathname.includes('/c/')) {
                    try {
                        if (window.location.host === "www.balsamhill.com" || window.location.host === "www.balsamhill.co.uk" || window.location.host === "www.balsamhill.com.au") {
                            categoryCrawl()
                        }
                        setTimeout(() => {
                            onload = false
                        }, 2000);
                    } catch (error) {
                        // console.log('error in crawling', error)
                    }

                }

                if (presentCart == "") {
                    setTimeout(() => {
                        if (document.querySelector('#inc_cart_1') || document.querySelector('#inc_cart_2')) {
                            presentCart = "product_cart"
                        } else if (document.querySelector('#inc_empty_cart_1') || document.querySelector('#inc_empty_cart_2')) {
                            presentCart = "empty_cart"
                        }
                    }, 1000);
                }
            }
        }, 1500);
    }
    
    function handleSearchChange() {
        let currentCount;
        if (location.pathname === previousUrl) {
            if (document.querySelectorAll('.productCard_title__60NqS')) {
                currentCount = document.querySelectorAll('.productCard_title__60NqS').length
            }

            if (lastProductCount !== currentCount) {
                if (window.location.pathname.includes('/c/')) {
                    if (onload == false) {
                        if (window.location.host === "www.balsamhill.com" || window.location.host === "www.balsamhill.co.uk" || window.location.host === "www.balsamhill.com.au") {
                            categoryCrawl()
                        }
                        lastProductCount = currentCount
                    } else {
                        lastProductCount = document.querySelectorAll('.productCard_title__60NqS').length
                    }
                }
            }

            if (lastPageType == "CartPage") {

                if (document.querySelector('#inc_cart_1') || document.querySelector('#inc_cart_2')) {

                    if (presentCart === "empty_cart") {
                        // console.log("FOUND CHANGE NOW CART")
                        presentCart = "product_cart"

                    }

                } else if (document.querySelector('#inc_empty_cart_1') || document.querySelector('#inc_empty_cart_2')) {

                    if (presentCart === "product_cart") {
                        // console.log("FOUND CHANGE NOW EMPTY")
                        presentCart = "empty_cart"
                        inc_delete_old()
                        if (domainCheck() === false) return
                        if (pageTypeCheck() !== null) {
                            setTimeout(() => {
                                if (document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/bA15huS/js/increasingly_bA15huS.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/b58lus/js/increasingly_b58lus.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://jp.increasingly.co/Implementation/bA15haU/js/increasingly_bA15haU.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://www.increasingly.co/Implementation/bA15huK/js/increasingly_bA15huK.js?v=1.0"]').length >= 1) {
                                    if (document.querySelector('.inc_js_files_' + versionUpdate + '') == null && window.location.href.indexOf('checkout') == -1) {
                                        function addCSSFile() {
                                            var cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.css?v=" + versionUpdate;
                                            var linkTag = document.createElement('link');
                                            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                                cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.css?v=" + versionUpdate;
                                            }
                                            linkTag.rel = "stylesheet";
                                            linkTag.href = cssFilePath;
                                            document.querySelector('head').appendChild(linkTag);
                                        }
                                        addCSSFile()
                                        setTimeout(() => {
                                            var jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.js?v=" + versionUpdate
                                            if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                                jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.js?v=" + versionUpdate
                                            }
                                            var scriptTag = document.createElement('script');
                                            scriptTag.setAttribute('class', 'inc_js_files_' + versionUpdate + '')
                                            scriptTag.type = 'text/javascript';
                                            scriptTag.src = jsFilePath;
                                            document.querySelector('body').appendChild(scriptTag);
                                            setTimeout(function () {
                                                if (document.querySelector('.inc_js_files_' + versionUpdate + '') != null) {
                                                    document.querySelector('.inc_js_files_' + versionUpdate + '').className = "c"
                                                }
                                            }, 4500)
                                        }, 500);
                                    }
                                }
                            }, 1500);

                        }
                    }
                }
            }
        }
        
        if (pageTypeCheck() == "SearchPage"){
            if (oldSearch !== window.location.search){
                // console.log("Search Change Detected")
                oldSearch = window.location.search

                if (document.querySelector('#inc_plp_1')) document.querySelector('#inc_plp_1').innerHTML = ""
                if (document.querySelector('#inc_plp_2')) document.querySelector('#inc_plp_2').innerHTML = ""

                if ( document.querySelector('#inc_plp_1')){
                    document.querySelector('#inc_plp_1').parentElement.parentElement.style.setProperty("display", "none", "important");
                }
                setTimeout(() => {
                    if (document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/bA15huS/js/increasingly_bA15huS.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://usaincreasingly.increasingly.co/Implementation/b58lus/js/increasingly_b58lus.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://jp.increasingly.co/Implementation/bA15haU/js/increasingly_bA15haU.js?v=1.0"]').length >= 1 || document.querySelectorAll('script[src="https://www.increasingly.co/Implementation/bA15huK/js/increasingly_bA15huK.js?v=1.0"]').length >= 1) {
                        if (document.querySelector('.inc_js_files_' + versionUpdate + '') == null && window.location.href.indexOf('checkout') == -1) {
                            function addCSSFile() {
                                var cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.css?v=" + versionUpdate;
                                if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                    cssFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.css?v=" + versionUpdate;
                                }
                                var linkTag = document.createElement('link');
                                linkTag.rel = "stylesheet";
                                linkTag.href = cssFilePath;
                                document.querySelector('head').appendChild(linkTag);
                            }
                            addCSSFile()
                            setTimeout(() => {
                                var jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/react/bundle.js?v=" + versionUpdate
                                if(window.location.host === 'uat-ui.i.balsamhill.com'){
                                    jsFilePath = "https://usaincreasingly.increasingly.co/Implementation/b58lus/uat/bundle.js?v=" + versionUpdate
                                }
                                var scriptTag = document.createElement('script');
                                scriptTag.setAttribute('class', 'inc_js_files_' + versionUpdate + '')
                                scriptTag.type = 'text/javascript';
                                scriptTag.src = jsFilePath;
                                document.querySelector('body').appendChild(scriptTag);
                                setTimeout(function () {
                                    if (document.querySelector('.inc_js_files_' + versionUpdate + '') != null) {
                                        document.querySelector('.inc_js_files_' + versionUpdate + '').className = "c"
                                    }
                                }, 4500)
                            }, 500);
                        }
                    }
                }, 1500);
            }
        }
    }
})()