//tealium universal tag - utag.98 ut4.0.202507090552, Copyright 2025 Tealium.com Inc. All Rights Reserved.
try{(function(id,loader,u){try{u=utag.o[loader].sender[id]={};}catch(e){u=utag.sender[id];}
u.ev={'view':1};u.qsp_delim="&";u.kvp_delim="=";u.acct="45290029";u.base_url="//js.hs-scripts.com/##utag_acct##.js";u.map={};u.extend=[];u.send=function(a,b,c,d,e,f){if(u.ev[a]||typeof u.ev.all!="undefined"){c=[];for(d in utag.loader.GV(u.map)){if(typeof b[d]!=="undefined"&&b[d]!==""){e=u.map[d].split(",");for(f=0;f<e.length;f++){c.push(e[f]+u.kvp_delim+encodeURIComponent(b[d]));}}}
u.base_url=u.base_url.replace("##utag_acct##",u.acct)
u.head=document.getElementsByTagName("head")[0];u.scr=document.createElement("script");u.scr.type="text/javascript";u.scr.src=u.base_url+c.join(u.qsp_delim);u.head.appendChild(u.scr);var _hsq=window._hsq=window._hsq||[];_hsq.push(['setPath',b['dom.pathname']]);_hsq.push(['trackPageView']);}}
try{utag.o[loader].loader.LOAD(id);}catch(e){utag.loader.LOAD(id);}})('98','balsam.balsamhill-tsu-en');}catch(e){}
