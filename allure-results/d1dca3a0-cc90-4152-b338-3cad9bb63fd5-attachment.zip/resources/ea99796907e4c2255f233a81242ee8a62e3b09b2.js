(function (_0x3b8be1, _0xdfb136) {
    var _0x24d006 = a0_0x3eec, _0x1b422e = _0x3b8be1();
    while (!![]) {
        try {
            var _0x4278d9 = -parseInt(_0x24d006(0x13f)) / 0x1 * (parseInt(_0x24d006(0x14a)) / 0x2) + -parseInt(_0x24d006(0x16f)) / 0x3 + -parseInt(_0x24d006(0x160)) / 0x4 * (-parseInt(_0x24d006(0x13d)) / 0x5) + parseInt(_0x24d006(0x16e)) / 0x6 * (parseInt(_0x24d006(0x144)) / 0x7) + -parseInt(_0x24d006(0x161)) / 0x8 + parseInt(_0x24d006(0x149)) / 0x9 * (parseInt(_0x24d006(0x131)) / 0xa) + -parseInt(_0x24d006(0x155)) / 0xb * (parseInt(_0x24d006(0x14e)) / 0xc);
            if (_0x4278d9 === _0xdfb136)
                break;
            else
                _0x1b422e['push'](_0x1b422e['shift']());
        } catch (_0x4f14fc) {
            _0x1b422e['push'](_0x1b422e['shift']());
        }
    }
}(a0_0x20c7, 0xa6c4b), ((() => {
    'use strict';
    var _0x14cb35 = a0_0x3eec;
    var _0x2e1e27 = _0x14cb35(0x13c);
    const _0xef355b = function (_0x504497) {
        var _0x5d0b1f = _0x14cb35, _0x1cb997, _0x737906, _0x3729f4 = arguments[_0x5d0b1f(0x153)] > 0x1 && void 0x0 !== arguments[0x1] ? arguments[0x1] : _0x2e1e27;
        return null !== (_0x1cb997 = null === (_0x737906 = document[_0x5d0b1f(0x15c)](_0x3729f4)) || void 0x0 === _0x737906 ? void 0x0 : _0x737906[_0x5d0b1f(0x146)](_0x504497)) && void 0x0 !== _0x1cb997 ? _0x1cb997 : void 0x0;
    };
    var _0x8b5133 = _0x14cb35(0x13a);
    const _0x22b039 = function (_0xaf8a38) {
        var _0x42e905 = _0x14cb35, _0x32f54c;
        (null !== (_0x32f54c = window[_0x42e905(0x15e)]) && void 0x0 !== _0x32f54c ? _0x32f54c : {})[_0x42e905(0x168)] && console[_0x42e905(0x15b)](_0xaf8a38);
    };
    var _0x57b6db = 'w2txo5aa', _0x5f3b7c = 'imgs.signifyd.com', _0x2ab269 = 'data-order-session-id';
    const _0x3cffbd = function (_0x38b615) {
        var _0xab97c1 = _0x14cb35;
        console['error'](_0x38b615);
        try {
            var _0x55fcc9 = new CustomEvent(_0xab97c1(0x142), { 'detail': _0x38b615 });
            document['dispatchEvent'](_0x55fcc9);
        } catch (_0x30d53b) {
            var _0x20dd6f = document['createEvent'](_0xab97c1(0x151));
            _0x20dd6f[_0xab97c1(0x15f)](_0xab97c1(0x142), !0x0, !0x0), _0x20dd6f[_0xab97c1(0x157)] = _0x38b615, document['dispatchEvent'](_0x20dd6f);
        }
    };
    var _0x60107a = '__SCRIPTLOADER__\x20ERROR\x20MESSAGE:\x20No\x20session\x20ID\x20found.\x0a\x20Make\x20sure\x20an\x20order\x20session\x20ID\x20is\x20set\x20in\x20the\x20\x22data-order-session-id\x22\x20attribute\x20of\x20the\x20script\x20tag.';
    const _0x463974 = function (_0xe31012) {
        var _0xe801a4 = _0x14cb35, _0x4f4d1b, _0x575505 = arguments[_0xe801a4(0x153)] > 0x1 && void 0x0 !== arguments[0x1] ? arguments[0x1] : _0xe801a4(0x137);
        _0x22b039(_0xe801a4(0x14b)['concat'](_0xe31012)), null !== (_0x4f4d1b = _0xe801a4(0x133) === _0xef355b(_0xe801a4(0x167))) && void 0x0 !== _0x4f4d1b && _0x4f4d1b ? function (_0x26045e, _0x5e44db) {
            var _0x2ddef7 = _0xe801a4;
            _0x22b039('Adding\x20script\x20loader\x20as\x20iframe');
            var _0x57d1f3 = document[_0x2ddef7(0x15d)](_0x2ddef7(0x15a));
            _0x57d1f3[_0x2ddef7(0x14d)](_0x2ddef7(0x150), 'width:\x20100px;\x20height:\x20100px;\x20border:\x200;\x20position:\x20absolute;\x20top:\x20-5000px;'), _0x57d1f3['setAttribute'](_0x2ddef7(0x162), _0x26045e), _0x57d1f3['setAttribute']('data-id', _0x2ddef7(0x148)), 'immediately' === _0x5e44db ? document[_0x2ddef7(0x135)][_0x2ddef7(0x156)](_0x57d1f3) : window[_0x2ddef7(0x16a)](_0x2ddef7(0x13b), function () {
                var _0x507cc6 = _0x2ddef7;
                _0x22b039(_0x507cc6(0x16d)), document[_0x507cc6(0x135)]['appendChild'](_0x57d1f3);
            });
        }(_0xe801a4(0x132)[_0xe801a4(0x164)](_0x5f3b7c, _0xe801a4(0x166))['concat'](_0x57b6db, _0xe801a4(0x138))[_0xe801a4(0x164)](_0xe31012, _0xe801a4(0x163)), _0x575505) : function (_0x275cab, _0x32eb10, _0x4c2050, _0x546037) {
            var _0x5df3f5 = _0xe801a4;
            if (_0x22b039(_0x5df3f5(0x143)), ![
                    atob('Q2hyb21lLUxpZ2h0aG91c2U='),
                    atob(_0x5df3f5(0x14f))
                ][_0x5df3f5(0x140)](function (_0x2d831f) {
                    var _0x1542fa = _0x5df3f5;
                    return navigator['userAgent'][_0x1542fa(0x145)](_0x2d831f);
                })) {
                if (_0x275cab) {
                    var _0x2311bb = document[_0x5df3f5(0x15d)]('script');
                    _0x2311bb['setAttribute']('type', _0x5df3f5(0x158)), _0x2311bb['setAttribute'](_0x5df3f5(0x162), _0x275cab), _0x2311bb[_0x5df3f5(0x14d)]('id', 'script-tag-tmx'), _0x2311bb['setAttribute'](_0x5df3f5(0x16b), _0x5df3f5(0x165)), _0x2311bb['onload'] = function () {
                        var _0x1ce277 = _0x5df3f5;
                        _0x22b039(_0x1ce277(0x141)[_0x1ce277(0x164)](_0x546037, '\x27')), threatmetrix[_0x1ce277(0x172)](_0x32eb10, _0x4c2050, _0x546037, 0x2);
                    }, document[_0x5df3f5(0x134)][_0x5df3f5(0x156)](_0x2311bb);
                }
                var _0x30f0d2 = new MutationObserver(function (_0x39ea5e) {
                        _0x39ea5e['forEach'](function () {
                            var _0x402d7c = a0_0x3eec, _0x1216a4 = _0xef355b(_0x2ab269);
                            _0x1216a4 ? (_0x22b039(_0x402d7c(0x159)['concat'](_0x1216a4, _0x402d7c(0x152))['concat'](_0x546037)), threatmetrix[_0x402d7c(0x172)](_0x32eb10, _0x4c2050, _0x1216a4, 0x2)) : _0x3cffbd(_0x60107a);
                        });
                    }), _0x523199 = document['querySelector'](_0x2e1e27);
                _0x30f0d2[_0x5df3f5(0x170)](_0x523199, { 'attributeFilter': [_0x2ab269] });
            }
        }(_0xe801a4(0x169), _0x5f3b7c, _0x57b6db, _0xe31012);
    };
    !function (_0x2f68c9) {
        var _0x325fb8 = _0x14cb35;
        if (window[_0x325fb8(0x171)] = null !== (_0x2f68c9 = window[_0x325fb8(0x171)]) && void 0x0 !== _0x2f68c9 ? _0x2f68c9 : { 'isInitialized': !0x1 }, window['sigScriptLoader'][_0x325fb8(0x13e)])
            _0x3cffbd('Signifyd\x20script\x20loader\x20is\x20already\x20initialized\x20-\x20please\x20check\x20that\x20the\x20tag\x20is\x20only\x20included\x20once');
        else {
            window[_0x325fb8(0x171)][_0x325fb8(0x13e)] = !0x0, _0x329379 = _0x325fb8(0x133) === function (_0x428159) {
                var _0x35af49 = _0x325fb8, _0x5a1e92, _0x367630 = ';\x20'[_0x35af49(0x164)](document[_0x35af49(0x14c)])[_0x35af49(0x139)](';\x20'[_0x35af49(0x164)](_0x428159, '='));
                if (0x2 === _0x367630[_0x35af49(0x153)])
                    return null === (_0x5a1e92 = _0x367630['pop']()) || void 0x0 === _0x5a1e92 ? void 0x0 : _0x5a1e92[_0x35af49(0x139)](';')[_0x35af49(0x154)]();
            }(_0x8b5133) || !!_0xef355b(_0x325fb8(0x168)), window[_0x325fb8(0x15e)] = {
                'logging': _0x329379,
                'enableLogging': function () {
                    var _0x11bdbb = _0x325fb8;
                    window[_0x11bdbb(0x15e)][_0x11bdbb(0x168)] = !0x0, document[_0x11bdbb(0x14c)] = ''['concat'](_0x8b5133, _0x11bdbb(0x16c));
                },
                'disableLogging': function () {
                    var _0x29d574 = _0x325fb8;
                    window['SIG_SCRIPT_DEBUG'][_0x29d574(0x168)] = !0x1, document['cookie'] = ''[_0x29d574(0x164)](_0x8b5133, _0x29d574(0x136));
                }
            };
            var _0x5ae5d4 = (function () {
                var _0x8de7f0 = _0x325fb8, _0x377d96 = _0xef355b(_0x2ab269);
                if (_0x377d96) {
                    if (_0x8de7f0(0x147) !== _0x377d96)
                        return _0x377d96;
                    _0x3cffbd(function (_0x1b01d1) {
                        return '__SCRIPTLOADER__\x20ERROR\x20MESSAGE:\x20Session\x20ID\x20has\x20not\x20been\x20correctly\x20set.\x0a\x20Make\x20sure\x20an\x20order\x20session\x20ID\x20is\x20set\x20to\x20a\x20unique\x20value\x20in\x20the\x20\x22data-order-session-id\x22\x20attribute\x20of\x20the\x20script\x20tag.\x0a' + 'Current\x20order\x20sessionId\x20=\x20'['concat'](_0x1b01d1, '\x0a') + 'Please\x20see\x20https://developer.signifyd.com/api/#/reference/device-fingerprint';
                    }(_0x377d96));
                } else
                    _0x3cffbd(_0x60107a);
            }());
            _0x5ae5d4 && _0x463974(_0x5ae5d4);
        }
        var _0x329379;
    }();
})()));
function a0_0x3eec(_0xd9270c, _0x404968) {
    var _0x20c7aa = a0_0x20c7();
    return a0_0x3eec = function (_0x3eecca, _0x2a1794) {
        _0x3eecca = _0x3eecca - 0x131;
        var _0x2ebfff = _0x20c7aa[_0x3eecca];
        return _0x2ebfff;
    }, a0_0x3eec(_0xd9270c, _0x404968);
}
function a0_0x20c7() {
    var _0x12a29d = [
        'observe',
        'sigScriptLoader',
        'profile',
        '5978650fuYktV',
        'https://',
        'true',
        'head',
        'body',
        '=false',
        'onLoad',
        '&session_id=',
        'split',
        'sigDebugLogging',
        'load',
        '#script-tag-api,\x20#sig-api',
        '579030jPLHEY',
        'isInitialized',
        '23246lfggbM',
        'some',
        'TMX\x20script\x20loaded.\x20Calling\x20threatmetrix.profile()\x20with\x20\x27',
        'sigScriptError',
        'Adding\x20script\x20loader\x20as\x20script\x20tag',
        '3892049rZBNlY',
        'includes',
        'getAttribute',
        'YOUR-SESSION-ID-HERE',
        'script-tag-iframe',
        '9bpOuoe',
        '12hnMHxb',
        'On\x20initialization,\x20session\x20ID\x20is:\x20',
        'cookie',
        'setAttribute',
        '384iGJZNU',
        'R29vZ2xlIFBhZ2UgU3BlZWQgSW5zaWdodHM=',
        'style',
        'Event',
        '\x0aOld\x20session\x20ID:\x20',
        'length',
        'shift',
        '405064VTFGVQ',
        'appendChild',
        'detail',
        'text/javascript',
        'Session\x20id\x20changed.\x0aNew\x20session\x20ID:\x20',
        'iframe',
        'log',
        'querySelector',
        'createElement',
        'SIG_SCRIPT_DEBUG',
        'initEvent',
        '44jhFdXk',
        '242768FnUcUH',
        'src',
        '&pageid=2',
        'concat',
        'script-tag-tmx',
        '/fp/tags?org_id=',
        'data-tmx-noscript',
        'logging',
        'https://cdn-scripts.signifyd.com/api/company_toolkit.js',
        'addEventListener',
        'data-id',
        '=true',
        'iframe\x20loaded',
        '6QjMrif',
        '1189395itZbTs'
    ];
    a0_0x20c7 = function () {
        return _0x12a29d;
    };
    return a0_0x20c7();
}